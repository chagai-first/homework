# JavaScript的初级学习

## 基本知识

1.JavaScript可以同接受双引号和单引号如

~~~javascript
<p id="demo">JavaScript 可以更改 HTML 内容。</p>

<button type="button" onclick="document.getElementById('demo').innerHTML = 'Hello JavaScript!'>单击这里</button>
~~~

这里的hello world即可以用双引号也可以用单引号不影响输出的结果

## 基本语法

### 改变内容

~~~javascript
document.getElementById("demo").innerHTML = "Hello JavaScript";
~~~

利用getElementById

### 改变属性

~~~javascript
<button onclick="document.getElementById('demo').src='gun2.jpg'">换枪</button>
    <img id="demo" style="text-align: center;" src="gun.jpg" width="200" height="200" />
    <button onclick="document.getElementById('demo').src='gun.jpg'">换枪</button>
~~~

### 改变样式

~~~JavaScript
<script>
        function myfunction() {
            x = document.getElementById('demo')
            x.style.color = "red";
            x.style.fontsize = "20px";
        }
    </script>
~~~

### 隐藏显示元素

~~~javascript
p id="demo">我可以将自己隐藏起来</p>
    <button type="button" onclick="document.getElementById('demo').style.display='none'">点我</button>
 <p id="demo2" style="display: none;">hello world</p>
    <button type="button" onclick="document.getElementById('demo2').style.display='block'">点我</button>
~~~

小提示：把脚本置于 <body> 元素的底部，可改善显示速度，因为脚本编译会拖慢显示。

## js的使用

### 引入外部脚本

~~~javascript
<script src="myScript.js"></script>
~~~

==注意==**：**外部脚本不能包含 **<script>** 标签。

### js的数据显示

JavaScript 能够以不同方式“显示”数据：

- 使用 window.alert() 写入警告框

  ~~~javascript
  <script>
          window.alert('hello world')
      </script>
  ~~~

  

- 使用 document.write() 写入 HTML 输出

- 使用 innerHTML 写入 HTML 元素（这个用*=*）

- 使用 console.log() 写入浏览器控制台

### js的语句使用

js是一种编程语言其语法与C++相似

1. var定义变量

2. function申明函数

   ==JavaScript对大小写敏感==

==JavaScript 中不能使用连字符。它是为减法预留的==

undefined 未阐明的，未定义的

### js中的数据计算

两个典型的例子

~~~javascript
var x = "8" + 3 + 5;
var x = 3 + 5 + "8";
~~~

这两个输出的结果是不同的一个是835，一个是88

**所以：**==如果把要给数值放入引号中，其余数值会被视作字符串并被级联。==

### js let

- var的变量定义比let的变量定义更加的灵活

- let相当于给这个变量限定了一块区域，数据只会再这块区域有效，常常与`{}`连用

  ~~~javascript
  { 
    let x = 10;
  }
  ~~~

  这样你就无法从块外调取他

- var 定于变量时会取最后定义的量或者说离他最近的量，而let

- 使用 JavaScript 的情况下，全局作用域是 JavaScript 环境。

  在 HTML 中，全局作用域是 window 对象。

  通过 var 关键词定义的全局变量属于 window 对象：

  但let定义的全局变量不属于window对象

### js const

- JavaScript const 变量必须在声明时赋值：

  不正确

  ```
  const PI;
  PI = 3.14159265359;
  ```

  正确

  ```
  const PI = 3.14159265359;
  ```

- 通过 const 定义的变量不会被提升到顶端。

- const 变量不能在声明之前使用

  ~~~javascript
  carName = "Volvo";    // 你不可以在此处使用 carName
  const carName = "Volvo";
  ~~~

- 在块作用域内使用时const与let相似

- 但const虽然无法改变对象的原始值但可以对其属性改变

  ~~~javascript
  / 你可以创建 const 对象：
  const car = {type:"porsche", model:"911", color:"Black"};
  
  // 你可以更改属性：
  car.color = "White";
  
  // 你可以添加属性：
  car.owner = "Bill";
  ~~~

- 同样的方法在数组中一样适用

- 如果你这样定义就是错误的

  ~~~javascript
  const car = {type:"porsche", model:"911", color:"Black"};
  car = {type:"Volvo", model:"XC60", color:"White"};    // 错误
  ~~~

#### 以上说的let与const和var都不可以杂交

### 数据类型

可以分为数值，字符串，数组，对象等等

使用typeof可以查看数据的数据类型

~~~javascript
typeof "Bill"              // 返回 "string"
typeof 3.14                // 返回 "number"
typeof true                // 返回 "boolean"
typeof false               // 返回 "boolean"
typeof x                   // 返回 "undefined" (假如 x 没有值)
~~~

这些是返还原始数据

还可以返还复杂数据的typeof可以把对象，数组和null返还为object

把函数返还为function

~~~javascript
typeof {name:'Bill', age:62} // 返回 "object"
typeof [1,2,3,4]             // 返回 "object"
typeof null                  // 返回 "object"
typeof function myFunc(){}   // 返回 "function"
~~~

设置值为undefined是清空对象

对象定义要用`{}`定义数组用`[]`

### 函数

- 函数的语法

  函数由关键词function进行定义

  ~~~javascript
  function name(参数 1, 参数 2, 参数 3) {
      要执行的代码
  }
  ~~~

- 函数的调用

  分为三种

  当事件发生时（当用户点击按钮时）

  当 JavaScript 代码调用时

  自动的（自调用）

- 函数的返还

  利用return来做返还

  在用返还时既可以返还函数结果也可以返还函数的内容

  ~~~javascript
   document.getElementById("demo").innerHTML = toCelsius;
  ~~~

  这样就是返还函数内容

  ~~~javascript
  document.getElementById("demo").innerHTML = toCelsius();
  ~~~

  这样是返还函数结果

### 对象

假如对象是汽车那么

所有汽车都拥有同样的*属性*，但属性值因车而异。

所有汽车都拥有相同的*方法*，但是方法会在不同时间被执行。

- 两种方式访问对象的属性值

  一种为

  ~~~javascript
  objectName.propertyName
  ~~~

  一种为

  ~~~javascript
  objectName["propertyName"]
  ~~~

- 访问对象的方法

  ~~~javascript
  objectName.methodName()
  ~~~

  不加括号就会引入函数的定义

- this 关键词

  在函数定义中，this 引用该函数的“拥有者”。

  换言之，this.firstName 的意思是 *this 对象*的 firstName 属性

~~~javascript
fullName : function() {
    return this.firstName + " " + this.lastName;
~~~

this 指的是“拥有” fullName 函数的 *person 对象*。

# DOM

文档对象模型是处理网页内容的方法和接口

**W3C 文档对象模型（DOM）是中立于平台和语言的接口，它允许程序和脚本动态地访问、更新文档的内容、结构和样式**。

**HTML DOM 是关于如何获取、更改、添加或删除 HTML 元素的标准**。

# BOM

浏览器对象模型是与浏览器交互的方法和接口

window 是 BOM 对象，而非 js 对象；javacsript是通过访问BOM对象来访问、控制、修改客户端(浏览器)

 
